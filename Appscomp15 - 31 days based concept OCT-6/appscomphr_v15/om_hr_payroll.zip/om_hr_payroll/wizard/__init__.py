# -*- coding:utf-8 -*-

from . import hr_payroll_payslips_by_employees
from . import hr_payroll_contribution_register_report
from . import employee_timesheet_excel_report
from . import time_off_statement
from . import hr_payroll_excel_report
