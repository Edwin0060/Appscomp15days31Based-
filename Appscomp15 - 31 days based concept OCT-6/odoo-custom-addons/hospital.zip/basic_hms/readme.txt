
=> 15.0.0.1 : Imporved an index with enterprise edition.

=> 15.0.0.2 : Added print options and update some module report views
            : Added  new validaction and update some field in patient
            : Fixed Diseases and Diseases category menu 
