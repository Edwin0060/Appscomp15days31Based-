console.log("=====================++++++++++++++++++===========")
odoo.define('pos_dashboard_ks.PosPage', function(require) {
'use strict';

     const TicketScreen = require('point_of_sale.TicketScreen');
     const { useListener } = require('web.custom_hooks');
     const Registries = require('point_of_sale.Registries');

     const PosOrderScreen = (TicketScreen) =>
        class extends TicketScreen {
            constructor() {
                super(...arguments);
                useListener('click-order', this._onClickOrder);
            }
            _onClickOrder({ detail: clickedOrder }) {
                this._setOrder(clickedOrder);
                this.render();
            }

        }
   Registries.Component.extend(TicketScreen, PosOrderScreen);
   return PosOrderScreen;
});