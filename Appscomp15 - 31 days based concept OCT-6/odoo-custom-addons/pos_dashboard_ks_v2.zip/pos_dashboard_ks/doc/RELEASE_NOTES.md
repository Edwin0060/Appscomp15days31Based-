## Module <pos_dashboard_ks>

#### 23.09.2022
#### Version 15.0.0.0

##### Initial Commit for pos_dashboard_ks

