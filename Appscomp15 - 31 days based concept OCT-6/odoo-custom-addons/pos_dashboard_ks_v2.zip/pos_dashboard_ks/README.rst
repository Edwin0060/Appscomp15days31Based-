POS Kitchen Screen Dashboard
============================
POS Kitchen Screen Dashboard

Installation
============
	- www.odoo.com/documentation/15.0/setup/install.html
	- Install our custom addon

Configuration
=============

    No additional configurations needed

Credits
=======
Developer: Fawas V15 @ cybrosys, Contact: odoo@cybrosys.com

