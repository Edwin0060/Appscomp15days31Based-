
Module for Complete Hotel management which includes the basic operations at a hotel/apartment.

You can manage:

* Configure Property

* Hotel Configuration

* Manage history of Check In, Check out

* Manage Folio

* Payment
